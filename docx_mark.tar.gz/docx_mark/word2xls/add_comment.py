# -*- coding: utf-8 -*-
# @Time    : 2019/2/1
# @Author  : jxjiang

import copy
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.table import _Cell
from .config.log_setting import get_logger
from .word_util import Word07
import time

log = get_logger('add_comment')

def build_location_to_block_dicts(input_file_path):

    last_time = time.time()
    log.info('extracting table from docx...')
    try:
        word = Word07(input_file_path)
    except Exception as e:
        raise e

    word.extract_docx_all()
    log.info('[word main cost] extract_docx_all, time={:.5f}'.format(time.time()-last_time))

    paixu_id_to_block_dict, cell_id_to_block_dict = word.generate_location_dict()

    return word, paixu_id_to_block_dict, cell_id_to_block_dict

def make_element(which, id):
    element = OxmlElement('w:{}'.format(which))
    element.set(qn('w:id'), str(id))
    return element


def _add_comment(block, start_pos, end_pos, comment_id):
    shift_pos = 0
    region_list = []
    #target_region = []

    log.info('region len={}'.format(len(block._p.r_lst)))

    for idx, region in enumerate(block._p.r_lst):
        log.info('region index={}, shift={}'.format(idx, shift_pos))

        region_text_len = len(region.text)

        if shift_pos + region_text_len < start_pos or end_pos <= shift_pos:
            region_list.append(region)
            shift_pos += region_text_len
            continue
        # if start_pos < shift_pos:
        #     if end_pos <= shift_pos + len(region.text):
        #         # 删除到end_pos为止到字符
        #         pass
        #         continue
        #     else:
        #         # remove hole region
        #         continue
        # 替换范围在一个region内
        else:
            log.info('add comment, region idx={}, comment id={}'.format(idx, comment_id))
            log.info('start={}, end={}, text_len={}, shift={}'.format(start_pos, end_pos, region_text_len, shift_pos))
            # TODO replace
            ori_text = region.text
            region_template = copy.deepcopy(region)

            region_sub_start_pos = 0

            if shift_pos <= start_pos and start_pos < shift_pos + region_text_len:
                comment_start_pos = start_pos - shift_pos
                if comment_start_pos != region_sub_start_pos:
                    region.text = ori_text[region_sub_start_pos: comment_start_pos]
                    region_list.append(region)

                comment_start = make_element('commentRangeStart', comment_id)
                region_list.append(comment_start)

                region_sub_start_pos = comment_start_pos


            if shift_pos < end_pos and end_pos <= shift_pos + region_text_len:
                comment_end_pos = end_pos - shift_pos
                target_region = copy.deepcopy(region_template)
                target_region.text = ori_text[region_sub_start_pos: comment_end_pos]
                region_list.append(target_region)

                comment_end = make_element('commentRangeEnd', comment_id)
                region_list.append(comment_end)

                region_sub_start_pos = comment_end_pos


            if region_sub_start_pos != region_text_len:
                suffix_region = copy.deepcopy(region_template)
                suffix_region.text = ori_text[region_sub_start_pos:]
                region_list.append(suffix_region)


            shift_pos += region_text_len

    block.clear()
    for region in region_list:
        block._p.append(region)

    commentReference = make_element('commentReference', comment_id)
    r2 = block.add_run()
    r2._r.addnext(commentReference)


def add_comments_to_docx(locate_id_to_block_dict, comment_request_list, locate_param_name='paixu_id'):
    log.info('start add_comments_to_docx {}'.format(locate_param_name))
    log.info('comment_request length={}'.format(len(comment_request_list)))
    for idx, comment_request in enumerate(comment_request_list):
        log.info('comment index={}'.format(idx))
        locate_id = comment_request.get(locate_param_name)
        
        block_to_comment = locate_id_to_block_dict.get(locate_id)
        if block_to_comment is None:
            log.error('wrong comment info, {}={}'.format(locate_param_name, locate_id))
            continue

        block = block_to_comment.get('block')
        print('text len={} shift={}, start={}, end={}'.format(len(block.text), block_to_comment.get('start_pos'),
                                                              comment_request.get('comment_start'),
                                                              comment_request.get('comment_end')))

        if isinstance(block, _Cell):
            if len(block.paragraphs) == 0:
                log.error('no paragraph in cell. danyuange_id={}'.format(locate_id))
            elif len(block.paragraphs) == 1:
                block = block.paragraphs[0]
            else:
                for p_in_cell in block.paragraphs:
                    if len(p_in_cell.text) != 0:
                        block = p_in_cell
                        break
                else:
                    block = block.paragraphs[0]
        else:
            print('text len={} shift={}, start={}, end={}'.format(len(block.text), block_to_comment.get('start_pos'),
                                                        comment_request.get('comment_start'), comment_request.get('comment_end')) )

        content_start_pos = block_to_comment.get('start_pos')

        comment_start = comment_request.get('comment_start')
        if comment_start == -1:
            real_comment_start = 0
        else:
            real_comment_start = content_start_pos + comment_start

        comment_end = comment_request.get('comment_end')
        if comment_end == -1:
            real_comment_end = len(block.text)
        else:
            real_comment_end = content_start_pos + comment_end

        comment_id = comment_request.get('comment_id')

        _add_comment(block, real_comment_start, real_comment_end, comment_id)
    log.info('finish add_comment_to_paragraph {}'.format(locate_param_name))


def __add_comment_example():
    docx_path = 'input.docx'
    # 初始化
    word, paixu_id_to_block_dict, cell_id_to_block_dict = build_location_to_block_dicts(docx_path)

    # 添加批注
    text_comment = [{}]
    add_comments_to_docx(paixu_id_to_block_dict, text_comment, 'paixu_id')

    table_comment = [{}]
    add_comments_to_docx(cell_id_to_block_dict, table_comment, 'danyuange_id')

    # 输出添加后的文档
    save_path = 'test.docx'
    word.save_to(save_path)