# -*- coding: utf-8 -*-
# @Time    : 2019/2/13
# @Author  : jxjiang

from .config.log_setting import get_logger
import traceback

log = get_logger('word_common')

def generate_cell_id(table_id, index_row, index_column):

    try:
        cell_id = int(table_id) * 10**10 + int(index_row) * 10**5 + int(index_column)
    except Exception as e:
        log.error('generate cell id fail')
        log.error('tableid={}, row={}, col={}'.format(table_id, index_row, index_column))
        log.error(traceback.format_exc())
        cell_id = 0
    return str(cell_id)

def parsing_cell_id(danyuange_id):
    # danyuange_id 公式 page * 10 ^ 10 + y * 10 ^ 5 + x
    danyuange_id = int(danyuange_id)
    table_page = danyuange_id / 10 ** 10
    y = danyuange_id % 10 ** 10 / 10 ** 5
    x = danyuange_id % 10 ** 5

    return table_page, x, y