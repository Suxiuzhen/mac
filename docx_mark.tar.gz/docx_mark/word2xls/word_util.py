# -*- coding: utf-8 -*-
# @Time    : 2018/7/17
# @Author  : jxjiang

from docx import Document
from docx.document import Document as _Document
from docx.oxml.text.paragraph import CT_P
from docx.oxml.table import CT_Tbl
from docx.table import _Cell, Table
from docx.text.paragraph import Paragraph
from .config.log_setting import get_logger
from .word_common import generate_cell_id

import time
import multiprocessing
from itertools import zip_longest

log = get_logger('word07')


class Word07(object):

    def __init__(self, file_path, output_root=None):
        self.file_path = file_path
        try:
            self.doc = Document(file_path)
        except Exception as e:
            log.error('open docx fail. file path={}'.format(file_path))
            raise e

        self.table_num = 1
        self.strategy = 0  #  0:不对原文档表格做处理 1：重画表格 2:显示表格线（显示表格线存在显示不全的问题）
        self.is_filter_table_content = True  # 对单元格内容过滤，当前只有1条规则：过滤只有---的表格内容（一个'-'除外）

        self.result_dict = {}

    def extract_docx_all(self, multiprocess_num=0):
        log.info('start extract_table_to_excel')
        if multiprocess_num == 0:
            paixu_block_list = self.extract_content(self.doc)
        else:
            paixu_block_list = \
                self.multiprocess_exctract_content(self.doc, multiprocess_num=multiprocess_num)

        self.paixu_block_list = paixu_block_list
        log.info('finish extract_table_to_excel')

    def generate_location_dict(self):
        self.paixu_id_to_block_dict = {}
        self.cell_id_to_block_dict = {}
        paixu_id = 0

        for content_part in self.paixu_block_list:
            if isinstance(content_part, list):
                for table_block_dict in content_part:
                    for (row_idx, col_idx), cell_block in table_block_dict.items():
                        danyuange_id = generate_cell_id(paixu_id, row_idx, col_idx)
                        self.cell_id_to_block_dict[danyuange_id] = {'start_pos': 0, 'end_pos': len(cell_block.text),
                                                        'block': cell_block}
                    paixu_id += 1
            elif isinstance(content_part, Paragraph):
                start_pos = 0

                stripped_text = content_part.text.lstrip()
                if stripped_text != content_part.text:
                    start_pos += len(content_part.text) - len(stripped_text)

                sub_text_list = stripped_text.split('\n')
                for sub_text in sub_text_list:
                    end_pos = start_pos + len(sub_text)
                    self.paixu_id_to_block_dict[str(paixu_id)] = {'start_pos': start_pos, 'end_pos': end_pos,
                                                        'block': content_part}

                    start_pos = end_pos + 1 # 跳过\n
                    paixu_id += 1

        return self.paixu_id_to_block_dict, self.cell_id_to_block_dict



    def iter_block_items(self, parent):
        if isinstance(parent, _Document):
            parent_elm = parent.element.body
        elif isinstance(parent, _Cell):
            parent_elm = parent._tc
        else:
            raise ValueError("something's not right")
        for child in parent_elm.iterchildren():
            if isinstance(child, CT_P):
                yield Paragraph(child, parent)
            elif isinstance(child, CT_Tbl):
                yield Table(child, parent)


    def _generate_content_list(self, label, text, level):
        content_list = []
        text_list = text.split('\n')
        for cur_text in text_list:
            if cur_text:
                #cur_text = self.filter_ignore_word(cur_text)
                content_list.append([label, cur_text, level])
        return content_list



    """
    main function to extract tables
    """
    def extract_content(self, document, read_paragraph=True, read_table=True):
        '''
        抽取word中的表格数据， 根据策略self.strategy不同，可重绘或导出表格。
        附带功能：把表格中到文字、表格信息保存到self.heading_data_list，给下游找表名流程使用
        :param document:
        :param read_paragraph:
        :param read_table:
        :return:
        '''

        paixu_block_list = []

        all_block = [b for b in self.iter_block_items(document)]

        # TODO DEBUG CODE 1 start
        parag_time_count = 0
        table_time_count = 0
        parag_total_count = 0
        parag_count = 0
        # TODO DEBUG CODE 1 end
        last_time = time.time()
        pre_para = None
        for block_index, block in enumerate(all_block):
            # TODO DEBUG CODE 2 start
            if isinstance(block, Table):
                log.debug('[extract_content] para block count={}, \t\ttime={:.5f}'.format(parag_count, time.time() - last_time))
                parag_time_count += time.time() - last_time
                last_time = time.time()
                parag_total_count += parag_count
                parag_count = 0
            else:
                parag_count += 1
            # TODO DEBUG CODE 2 end

            block_data = self.parsing_block(block, read_paragraph, read_table)

            if block_data or (not read_table and block_data == []):
                if isinstance(block, Paragraph):
                    pre_para = block
                    block_text = block.text.strip()
                    if block_text != '':
                        paixu_block_list.append(block_data)

                elif isinstance(block, Table):
                    log.debug('[extract_content] parsing table block, \t\ttime={:.5f}'.format(time.time() - last_time))
                    parag_time_count += time.time() - last_time
                    last_time = time.time()

                    paixu_block_list.append(block_data)

                    log.debug('[extract_content] save block data, \t\ttime={:.5f}'.format(time.time() - last_time))
                    table_time_count += time.time() - last_time
                    last_time = time.time()
        log.debug('[time cost] parag_count={}, parag={}, table={}'.format(parag_total_count, parag_time_count, table_time_count))
        return paixu_block_list

    def parsing_block(self, block, read_paragraph=True, read_table=True, is_recursive_table=False):
        result = []
        table_dict_list = []
        if isinstance(block, str):
            log.warning('block is string')
            return block

        elif read_paragraph and isinstance(block, Paragraph):
            return block

        elif read_table and isinstance(block, Table):
            last_time = time.time()
            if self.table_num == 15:
                print()
            is_min_table = 1

            table_content_dict = {}
            max_row = 0
            max_col = 0
            last_time = time.time()
            try:
                for row in block.rows:
                    try:
                        for cell in row.cells:
                            cell_data = self.parsing_block(cell)

                            max_row = max(cell._tc._tr_idx, max_row)
                            max_col = max(cell._tc._grid_col, max_col)
                            if isinstance(cell_data, list):
                                is_min_table = 0
                                table_dict_list.extend(cell_data)
                            elif table_dict_list == []:
                                table_content_dict[(cell._tc._tr_idx, cell._tc._grid_col)] = cell_data
                    except Exception as e:
                        log.error('read table row error, table num={}'.format(self.table_num))

            except Exception as e:
                log.error('read table error, table num={}'.format(self.table_num))
            max_row += 1
            max_col += 1
            log.debug('[parsing_block] parsing cell. idx={}, \t\ttime={:.5f}'.format(self.table_num, time.time() - last_time))
            last_time = time.time()

            if is_recursive_table and max_row == 1 and max_col == 1:
                single_cell = block.cell(0, 0)
                return single_cell

            log.debug('[parsing_block] rebuild  table. idx={}, \t\ttime={:.5f}'.format(self.table_num, time.time() - last_time))
            last_time = time.time()
            if is_min_table:
                log.info("finish current table num " + str(self.table_num))
                self.table_num += 1
            #log.debug('[parsing_block] deal min table. idx={}, \t\ttime={:.5f}'.format(self.table_num-1, time.time() - last_time))
            last_time = time.time()
            if table_dict_list == []:
                table_dict_list.append(table_content_dict)
            result = table_dict_list

        elif read_table and isinstance(block, _Cell):
            # 表格嵌套表格的情况
            if block.tables:
                if len(block.tables) == 1:
                    t_data = self.parsing_block(block.tables[0], is_recursive_table=True)
                    if isinstance(t_data, _Cell):
                        # 嵌套的表格中仅一个单元格，则不作为嵌套表格处理
                        return t_data
                    else:
                        table_dict_list.extend(t_data)
                else:
                    for t in block.tables:
                        t_data = self.parsing_block(t, is_recursive_table=True)
                        table_dict_list.extend(t_data)

                return table_dict_list
            # 普通单元格
            else:
                return block

        return result

    def deal_single_cell_table(self, result):
        '''对嵌套表格中，内层表格只有一个单元格对情况做特殊处理：提出内层表格内容，作为外层表格的一个普通单元格内容'''
        if len(result) == 1:
            if isinstance(result[0], tuple) and len(result[0]) == 3:
                table_contents = result[0][1]
                if len(table_contents) == 1 and len(table_contents[0]) == 1:
                    log.info('only one cell in recursive table, deal recursive table as a normal cell')
                    if self.is_filter_table_content:
                        text = self.filter_table_content(table_contents[0][0])
                    return text
            elif isinstance(result[0], list) and len(result[0]) == 1:
                log.info('only one cell table, deal table as paragraph')
                if self.is_filter_table_content:
                    text = self.filter_table_content(result[0][0])
                return text
        return None

    def save_to(self, path):
        self.doc.save(path)

    def multiprocess_exctract_content(self, document, read_paragraph=True, read_table=True, multiprocess_num=5):
        '''
        多进程抽表。
        部分功能未实现或未在多进程下验证，包括：重绘表格、用 rangeInfo 对 block 过滤
        self.table_num脏读脏写
        '''
        # iterator the blocks in doc

        result_dict = multiprocessing.Manager().dict()
        # if block_filter_range and not block_filter_range.is_empty():
        #     self.table_filter_info.set_filter_all()

        all_block = [b for b in self.iter_block_items(document)]
        pre_para = None


        sub_block_groups = self.process_list(all_block, process_num=multiprocess_num)

        table_index_offset_list = self.__count_table_offset(sub_block_groups)

        jobs = []
        log.debug("local_path_group:{}".format(len(sub_block_groups)))

        total_process_num = len(sub_block_groups)
        pool = multiprocessing.Pool(processes=total_process_num, maxtasksperchild=100)
        for irg in range(total_process_num):
        #     p = multiprocessing.Process(target=self.multiprocess_sub_extract,
        #                                 args=(irg, total_process_num, sub_block_groups[irg], table_index_offset_list[irg],
        #                                       result_dict, read_paragraph, read_table))
            p = pool.Process(target=self.multiprocess_sub_extract,
                                         args=(irg, total_process_num, sub_block_groups[irg],
                                              result_dict, read_paragraph, read_table,))
            jobs.append(p)
        for j in jobs:
            j.start()
        for j in jobs:
            j.join()

        #
        # pool = multiprocessing.Pool(processes=5, maxtasksperchild=100)
        # #my_args = list(zip(sub_block_groups, table_index_offset_list))
        # self.sub_block_groups = sub_block_groups
        # my_args = []
        # for i in range(len(sub_block_groups)):
        #     my_args.append((i, total_process_num, i, table_index_offset_list[i]))
        #     #my_args.append((1))
        # # partial_sub_extract = partial(self.multiprocess_sub_extract, result_dict = result_dict,
        # #                          read_paragraph=read_paragraph, read_table=read_table, block_filter_range=None)
        #
        # partial_sub_extract = partial(self.multiprocess_sub_extract, result_dict=None,
        #                               read_paragraph=read_paragraph, read_table=read_table, block_filter_range=None)
        #
        # pool.map(partial_sub_extract, my_args)

        pool.close()
        pool.join()

        paixu_block_list = []
        for process_idx in range(total_process_num):
            paixu_block_list.extend(result_dict[process_idx]['paixu_block_list'])

        self.paixu_block_list = paixu_block_list

        return paixu_block_list

    def __count_table_offset(self, sub_block_groups):
        table_index_offset_list = [0]
        cur_offset = 0
        for group_idx in range(len(sub_block_groups)-1):
            for block in sub_block_groups[group_idx]:
                if isinstance(block, Table):
                    cur_offset += 1
            table_index_offset_list.append(cur_offset)
        return table_index_offset_list


    def multiprocess_sub_extract(self, process_id, total_process_num, sub_block_list, result_dict,
                                 read_paragraph=True, read_table=True):
        last_time = time.time()
        paixu_block_list = []

        all_block = sub_block_list

        # TODO DEBUG CODE 1 start
        parag_time_count = 0
        table_time_count = 0
        parag_total_count = 0
        parag_count = 0
        # TODO DEBUG CODE 1 end
        last_time = time.time()

        for block_index, block in enumerate(all_block):
            # TODO DEBUG CODE 2 start
            if isinstance(block, Table):
                log.debug('[extract_content] para block count={}, \t\ttime={:.5f}'.format(parag_count,
                                                                                          time.time() - last_time))
                parag_time_count += time.time() - last_time
                last_time = time.time()
                parag_total_count += parag_count
                parag_count = 0
            else:
                parag_count += 1
            # TODO DEBUG CODE 2 end

            block_data = self.parsing_block(block, read_paragraph, read_table)

            if block_data or (not read_table and block_data == []):
                if isinstance(block, Paragraph):
                    block_text = block.text.strip()
                    if block_text != '':
                        paixu_block_list.append(block_data)

                elif isinstance(block, Table):
                    log.debug('[extract_content] parsing table block, \t\ttime={:.5f}'.format(time.time() - last_time))
                    parag_time_count += time.time() - last_time
                    last_time = time.time()

                    paixu_block_list.append(block_data)

                    log.debug('[extract_content] save block data, \t\ttime={:.5f}'.format(time.time() - last_time))
                    table_time_count += time.time() - last_time
                    last_time = time.time()
        log.debug('[time cost] parag_count={}, parag={}, table={}'.format(parag_total_count, parag_time_count,
                                                                          table_time_count))

        sub_result = {}
        sub_result['paixu_block_list'] = paixu_block_list
        result_dict[process_id] = sub_result
        log.info('sub extract done. {}/{}'.format(process_id+1, total_process_num))


    def process_list(self, df_cell_group, process_num=5):

        e_num = int(len(df_cell_group) / process_num + 1)
        # 切分列表用于多进程
        chunk_list = lambda a_list, n: zip_longest(*[iter(a_list)] * n)
        return list(chunk_list([x for x in df_cell_group], e_num))


if __name__ == '__main__':
    # document = Document('../data/财务报表模板-非上市(新准则合并).docx')
    # extract_tables(document)
    #word11= Document()
    #table = word11.add_table(rows=4, cols=2, style='Colorful Grid')
    # for row in table.rows:
    #     for cell in row.cells:
    #         curt = cell.add_table(rows=4, cols=2)
    #         curt.style = 'Table Grid'
    # table.style = 'Normal Table'
    #word11.save('../data/my2.docx')
    # print()
    #word = Word07('../data/word2excel/2017.ABC股份有限公司.QD.CN.AR.20180411.F.docx')



    word = Word07('../data/2017.ABC股份有限公司.QD.CN.AR.20180412.F1.docx')
    word.extract_docx_all('../data/a/new')
    word.save_to('../data/ABC股份有限公司_重画表格.docx')

    #word.save_heading_data('../data/head.csv')

    #convertDocxToPDF('../data/word2excel/ABC股份有限公司_重画表格.docx', '../data/word2excel/ABC股份有限公司_重画表格pdf.pdf')

